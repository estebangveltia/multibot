# 🧠 Frontend SaaS Multitenant con Next.js, Supabase y Prisma

Este proyecto es una plataforma base **multitenant y multiusuario**, construida con tecnologías modernas como **Next.js 14**, **TypeScript**, **Tailwind CSS**, **Shadcn/ui**, **Supabase** y **Prisma**.

Incluye:
- Autenticación personalizada (email/contraseña con Supabase)
- Control de acceso por roles jerárquicos
- Segmentación por empresa (tenant)
- Auditoría de accesos (login/logout)
- Gestión de “contextos” por empresa

## 🚀 Tecnologías

- **Next.js 14 (App Router)**
- **React + TypeScript**
- **Tailwind CSS + Shadcn/ui**
- **Lucide React Icons**
- **Supabase (Auth + PostgreSQL)**
- **Prisma ORM**
- **React Context + LocalStorage**

## 🧩 Estructura del Proyecto

```
├── app/
│   ├── login/                     → Página de login
│   ├── dashboard/                → Vistas por rol
│   │   └── nuevo-contexto/       → Crear nuevo contexto
├── components/ui/                → Componentes reusables
├── contexts/AuthContext.tsx      → Contexto de autenticación global
├── lib/
│   ├── supabaseClient.ts         → Cliente Supabase
│   ├── loginWithPrisma.ts        → Función login con auditoría
├── prisma/schema.prisma          → Esquema de base de datos
├── types/index.ts                → Tipos TypeScript globales
├── utils/protectRoute.tsx        → Protección de rutas por rol
└── .env.local                     → Variables de entorno
```

## 🔐 Roles soportados

- `superadmin`: acceso completo al sistema
- `admin_empresa`: gestiona usuarios y contextos de su tenant
- `usuario_empresa`: acceso limitado solo a su tenant

## 🧾 Modelos Prisma

### `Tenant`
```ts
id: string (uuid)
nombre: string
```

### `Usuario`
```ts
id: string (uuid) // = Supabase user id
email: string
rol: 'superadmin' | 'admin_empresa' | 'usuario_empresa'
tenantId: string (FK)
```

### `Contexto`
```ts
id: string
nombre: string
contenido: string
tenantId: string (FK)
```

### `AuditoriaUsuario`
```ts
id: string
id_usuario: string
id_tenant: string
accion: 'login' | 'logout'
fecha: timestamp
```

## 📦 Instalación y uso local

### 1. Clonar repositorio
```bash
git clone https://github.com/tu-usuario/frontend-saas-multitenant.git
cd frontend-saas-multitenant
```

### 2. Instalar dependencias
```bash
npm install
```

### 3. Configurar variables de entorno

Crea un archivo `.env.local`:

```env
NEXT_PUBLIC_SUPABASE_URL=https://<tu-proyecto>.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=ey...
DATABASE_URL=postgresql://postgres:<tu_pass>@<host>.supabase.co:5432/postgres
```

> Obtén estos valores desde Supabase:
> - `Settings > API` para URL y anon key
> - `Settings > Database` para `DATABASE_URL`

### 4. Configurar base de datos

Ejecuta el modelo:

```bash
npx prisma generate
npx prisma migrate dev --name init
```

O si la base ya existe:
```bash
npx prisma db pull
```

### 5. Levantar el entorno local
```bash
npm run dev
```

## 🧠 Funcionalidad destacada: Contextos

Los usuarios autenticados pueden:

- Ver contextos de su tenant
- Crear nuevos contextos (`/dashboard/nuevo-contexto`)
- Solo su empresa (tenant) puede ver o modificar estos datos

## 🧑‍💻 Licencia

Este proyecto está disponible para uso libre y puede ser adaptado a tu negocio SaaS. Agradece con una estrella ⭐ si te fue útil.
